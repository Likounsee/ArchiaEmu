//! Application settings page: about, updates, core settings and diagnostics.
//!
//! Every block is a `theme::card`, statuses are `theme::badge` pills, and all
//! colours come from the shared [`theme::Palette`] so the page follows the
//! light/dark mode and the accent colour chosen in the Appearance page.

use super::*;

/// State of the update section, derived once per frame.
#[derive(Clone, Copy, PartialEq, Eq)]
enum UpdateState {
    Unknown,
    Checking,
    Available,
    UpToDate,
    InstalledIsNewer,
}

/// A small section title with a one-line description, drawn above a card.
fn section_heading(ui: &mut egui::Ui, palette: &theme::Palette, title: &str, description: &str) {
    ui.add_space(18.0);
    ui.label(egui::RichText::new(title).size(17.0).strong());
    ui.label(
        egui::RichText::new(description)
            .size(13.0)
            .color(palette.text_dim),
    );
    ui.add_space(4.0);
}

/// One "label: value" line. The value wraps instead of overflowing the card,
/// which matters for long file paths.
fn key_value(
    ui: &mut egui::Ui,
    palette: &theme::Palette,
    label: &str,
    value: &str,
    monospace: bool,
) {
    ui.horizontal_top(|ui| {
        ui.vertical(|ui| {
            ui.set_width(190.0);
            ui.label(
                egui::RichText::new(label)
                    .size(13.0)
                    .color(palette.text_dim),
            );
        });
        ui.vertical(|ui| {
            let text = egui::RichText::new(value).size(13.0);
            ui.label(if monospace { text.monospace() } else { text });
        });
    });
}

impl DesktopApp {
    pub(super) fn show_settings(&mut self, ui: &mut egui::Ui, context: &egui::Context) {
        match self.settings_section {
            SettingsSection::Appearance => self.show_appearance(ui),
            SettingsSection::Application => self.show_application_settings(ui, context),
        }
    }

    fn show_application_settings(&mut self, ui: &mut egui::Ui, context: &egui::Context) {
        let palette = theme::Palette::new(self.dark_mode, self.accent_color);
        let french = self.language == "fr";
        let current = option_env!("CARGO_PKG_VERSION").unwrap_or("0.0.0");

        ui.label(egui::RichText::new("Application").size(30.0).strong());
        ui.label(
            egui::RichText::new(if french {
                "Informations, mises à jour et diagnostic de l’application."
            } else {
                "Application information, updates and diagnostics."
            })
            .color(palette.text_dim),
        );
        ui.add_space(8.0);
        ui.separator();

        // ---------------------------------------------------------------- About
        section_heading(
            ui,
            &palette,
            if french { "À propos" } else { "About" },
            if french {
                "Version installée et état du projet."
            } else {
                "Installed version and project status."
            },
        );
        theme::card(ui, &palette, |ui| {
            ui.set_width(ui.available_width());
            ui.horizontal(|ui| {
                let (slot, _) =
                    ui.allocate_exact_size(egui::vec2(56.0, 56.0), egui::Sense::hover());
                ui.painter()
                    .rect_filled(slot, egui::Rounding::same(14.0), palette.accent);
                ui.painter().text(
                    slot.center(),
                    egui::Align2::CENTER_CENTER,
                    "A",
                    egui::FontId::proportional(30.0),
                    palette.on_accent,
                );
                ui.vertical(|ui| {
                    ui.horizontal(|ui| {
                        ui.label(egui::RichText::new("ArchiaEmu").size(20.0).strong());
                        theme::badge(ui, &format!("v{current}"), palette.text_dim);
                        theme::badge(
                            ui,
                            if french { "Expérimental" } else { "Experimental" },
                            palette.warning,
                        );
                    });
                    ui.label(
                        egui::RichText::new(if french {
                            "ArchiaEmu est en cours de développement."
                        } else {
                            "ArchiaEmu is under active development."
                        })
                        .color(palette.text_dim),
                    );
                });
            });
            ui.add_space(6.0);
            ui.label(if french {
                "Le cœur Game Boy Color est expérimental ; le lancement d’une ROM ne garantit pas sa compatibilité."
            } else {
                "The Game Boy Color core is experimental; launching a ROM does not imply compatibility."
            });
            ui.label(
                egui::RichText::new(if french {
                    "Les chemins de la bibliothèque et les préférences visuelles sont enregistrés dans votre configuration utilisateur."
                } else {
                    "Imported library paths and appearance preferences are saved in your user configuration."
                })
                .size(13.0)
                .color(palette.text_dim),
            );
            ui.add_space(4.0);
            if ui
                .button(if french {
                    "Enregistrer les paramètres"
                } else {
                    "Save settings now"
                })
                .clicked()
                && self.save_preferences()
            {
                self.message = if french {
                    "Paramètres enregistrés.".to_owned()
                } else {
                    "Settings saved.".to_owned()
                };
            }
        });

        // -------------------------------------------------------------- Updates
        section_heading(
            ui,
            &palette,
            if french {
                "Mises à jour de l’application"
            } else {
                "Application updates"
            },
            if french {
                "Le manifeste officiel est vérifié au démarrage ; vous pouvez relancer la vérification ici. Les modules sont téléchargés séparément."
            } else {
                "The official stable manifest is checked at startup; you can also run a check here. Module downloads are independent."
            },
        );
        let checking = self.update_check_receiver.is_some();
        let downloading = self.update_download_receiver.is_some();
        let update_info = self.update_manifest.as_ref().map(|manifest| {
            (
                manifest.version.clone(),
                manifest.release_notes_url.clone(),
                manifest.download_for_current_platform().cloned(),
            )
        });
        let update_state = if checking {
            UpdateState::Checking
        } else if let Some((manifest_version, _, _)) = update_info.as_ref() {
            if update::is_newer_version(manifest_version, current) {
                UpdateState::Available
            } else if update::is_newer_version(current, manifest_version) {
                UpdateState::InstalledIsNewer
            } else {
                UpdateState::UpToDate
            }
        } else {
            UpdateState::Unknown
        };
        let (manifest_version, release_notes_url, download) = match update_info {
            Some((version, url, download)) => (Some(version), Some(url), download),
            None => (None, None, None),
        };
        let has_download = download.is_some();
        theme::card(ui, &palette, |ui| {
            ui.set_width(ui.available_width());
            ui.horizontal_wrapped(|ui| {
                match update_state {
                    UpdateState::Checking => theme::badge(
                        ui,
                        if french { "Vérification…" } else { "Checking…" },
                        palette.accent,
                    ),
                    UpdateState::Available => theme::badge(
                        ui,
                        if french {
                            "Mise à jour disponible"
                        } else {
                            "Update available"
                        },
                        palette.accent,
                    ),
                    UpdateState::UpToDate => theme::badge(
                        ui,
                        if french { "À jour" } else { "Up to date" },
                        palette.success,
                    ),
                    UpdateState::InstalledIsNewer => theme::badge(
                        ui,
                        if french {
                            "Plus récente que le manifeste"
                        } else {
                            "Newer than the manifest"
                        },
                        palette.warning,
                    ),
                    UpdateState::Unknown => theme::badge(
                        ui,
                        if french { "Non vérifié" } else { "Not checked" },
                        palette.text_dim,
                    ),
                }
                ui.label(
                    egui::RichText::new(&self.update_status)
                        .size(13.0)
                        .color(palette.text_dim),
                );
            });

            ui.horizontal_wrapped(|ui| {
                if ui
                    .add_enabled(
                        !checking,
                        egui::Button::new(if french {
                            "Rechercher des mises à jour"
                        } else {
                            "Check for updates"
                        }),
                    )
                    .clicked()
                {
                    self.start_update_check();
                    context.request_repaint_after(Duration::from_millis(250));
                }
                if update_state == UpdateState::Available {
                    if let (Some(download), Some(version)) = (download, manifest_version.clone()) {
                        if ui
                            .add_enabled(
                                !downloading,
                                theme::primary_button(
                                    &palette,
                                    if french {
                                        "Télécharger et vérifier la mise à jour"
                                    } else {
                                        "Download and verify update"
                                    },
                                ),
                            )
                            .clicked()
                        {
                            let (sender, receiver) = mpsc::channel();
                            self.update_download_receiver = Some(receiver);
                            self.update_status = if french {
                                format!("Téléchargement de la version {version} dans la zone temporaire…")
                            } else {
                                format!("Downloading version {version} to a temporary staging area…")
                            };
                            std::thread::spawn(move || {
                                let result = update::download_and_verify(&download, &version);
                                let _ = sender.send(result);
                            });
                            context.request_repaint_after(Duration::from_millis(250));
                        }
                    }
                }
            });
            if update_state == UpdateState::Available && !has_download {
                ui.label(
                    egui::RichText::new(if french {
                        "Aucun fichier de mise à jour installable n’est publié pour cette plateforme."
                    } else {
                        "No installable update artifact is currently published for this platform."
                    })
                    .size(13.0)
                    .color(palette.text_dim),
                );
            }

            if let Some(version) = manifest_version.as_ref() {
                ui.separator();
                key_value(
                    ui,
                    &palette,
                    if french {
                        "Version installée"
                    } else {
                        "Installed version"
                    },
                    current,
                    true,
                );
                key_value(
                    ui,
                    &palette,
                    if french {
                        "Version du manifeste"
                    } else {
                        "Manifest version"
                    },
                    &version.to_string(),
                    true,
                );
                if let Some(url) = release_notes_url.as_ref() {
                    ui.hyperlink_to(
                        if french {
                            "Notes de version"
                        } else {
                            "Release notes"
                        },
                        url,
                    );
                }
            }
            if let Some(path) = self.staged_update_path.as_ref() {
                ui.separator();
                key_value(
                    ui,
                    &palette,
                    if french {
                        "Fichier vérifié préparé"
                    } else {
                        "Verified staged file"
                    },
                    &path.display().to_string(),
                    true,
                );
                ui.label(
                    egui::RichText::new(if french {
                        "Le fichier est vérifié, mais n’a pas été installé ni exécuté."
                    } else {
                        "The file is verified but has not been installed or executed."
                    })
                    .size(13.0)
                    .color(palette.text_dim),
                );
            }
            ui.label(
                egui::RichText::new(if french {
                    "L’installation automatique et le retour arrière ne sont pas encore activés."
                } else {
                    "Automatic installation and rollback are not enabled yet."
                })
                .size(12.0)
                .color(palette.text_dim),
            );
        });

        // ---------------------------------------------------------- Core settings
        section_heading(
            ui,
            &palette,
            if french {
                "Paramètres du cœur"
            } else {
                "Core settings"
            },
            if french {
                "Séparés de l’apparence de l’application."
            } else {
                "Kept separate from the application appearance."
            },
        );
        theme::card(ui, &palette, |ui| {
            ui.set_width(ui.available_width());
            ui.horizontal_wrapped(|ui| {
                theme::badge(
                    ui,
                    if french { "Bientôt" } else { "Coming soon" },
                    palette.text_dim,
                );
                ui.label(if french {
                    "Aucun réglage matériel propre au cœur n’est actuellement proposé."
                } else {
                    "No core-specific hardware settings are currently exposed."
                });
            });
            ui.label(
                egui::RichText::new(if french {
                    "Ces réglages apparaîtront lorsqu’un futur cœur d’émulation les prendra en charge."
                } else {
                    "These settings will appear when a future emulation core supports them."
                })
                .size(13.0)
                .color(palette.text_dim),
            );
        });

        // ----------------------------------------------------------- Diagnostics
        section_heading(
            ui,
            &palette,
            "Diagnostic",
            if french {
                "Informations locales pour diagnostiquer les problèmes de démarrage et de session."
            } else {
                "Local runtime information to help troubleshoot startup and session issues."
            },
        );
        let none_text = if french { "aucune" } else { "none" };
        let unavailable_text = if french { "indisponible" } else { "unavailable" };
        let platform = format!("{} / {}", std::env::consts::OS, std::env::consts::ARCH);
        let library_items = self.controller.library().len().to_string();
        let open_sessions = self.controller.session_summaries().len().to_string();
        let error_count = self.last_tick_errors.len().to_string();
        let active_session = self
            .controller
            .active_session()
            .map(|id| id.get().to_string())
            .unwrap_or_else(|| none_text.to_owned());
        let config_path = self
            .config_path
            .as_deref()
            .map(|path| path.display().to_string())
            .unwrap_or_else(|| unavailable_text.to_owned());
        let staged_path = self
            .staged_update_path
            .as_deref()
            .map(|path| path.display().to_string())
            .unwrap_or_else(|| none_text.to_owned());
        theme::card(ui, &palette, |ui| {
            ui.set_width(ui.available_width());
            ui.spacing_mut().item_spacing.y = 6.0;
            key_value(
                ui,
                &palette,
                if french {
                    "Version de l’application"
                } else {
                    "Application version"
                },
                current,
                true,
            );
            key_value(
                ui,
                &palette,
                if french { "Plateforme" } else { "Platform" },
                &platform,
                true,
            );
            key_value(
                ui,
                &palette,
                if french {
                    "Éléments de la bibliothèque"
                } else {
                    "Library items"
                },
                &library_items,
                false,
            );
            key_value(
                ui,
                &palette,
                if french {
                    "Sessions ouvertes"
                } else {
                    "Open sessions"
                },
                &open_sessions,
                false,
            );
            key_value(
                ui,
                &palette,
                if french {
                    "Session active"
                } else {
                    "Active session"
                },
                &active_session,
                true,
            );
            key_value(
                ui,
                &palette,
                if french {
                    "Erreurs d’exécution"
                } else {
                    "Execution errors"
                },
                &error_count,
                false,
            );
            ui.separator();
            key_value(
                ui,
                &palette,
                if french {
                    "Fichier de configuration"
                } else {
                    "Configuration file"
                },
                &config_path,
                true,
            );
            key_value(
                ui,
                &palette,
                if french {
                    "État des médias"
                } else {
                    "Media status"
                },
                &self.media_status,
                false,
            );
            key_value(
                ui,
                &palette,
                if french {
                    "État des mises à jour"
                } else {
                    "Update status"
                },
                &self.update_status,
                false,
            );
            key_value(
                ui,
                &palette,
                if french {
                    "Mise à jour préparée"
                } else {
                    "Staged update"
                },
                &staged_path,
                true,
            );
            key_value(
                ui,
                &palette,
                if french {
                    "Dernier message"
                } else {
                    "Latest message"
                },
                &self.message,
                false,
            );
            if !self.last_tick_errors.is_empty() {
                ui.separator();
                ui.label(
                    egui::RichText::new(if french {
                        "Erreurs récentes des sessions"
                    } else {
                        "Recent session errors"
                    })
                    .strong()
                    .color(palette.danger),
                );
                for (session_id, error) in self.last_tick_errors.iter().take(5) {
                    ui.label(if french {
                        format!("Session {} : {error}", session_id.get())
                    } else {
                        format!("Session {}: {error}", session_id.get())
                    });
                }
            }
            ui.add_space(4.0);
            if ui
                .button(if french {
                    "Copier le diagnostic"
                } else {
                    "Copy diagnostics to clipboard"
                })
                .clicked()
            {
                let report = self.diagnostics_report(french);
                ui.output_mut(|output| output.copied_text = report);
                self.message = if french {
                    "Diagnostic copié dans le presse-papiers.".to_owned()
                } else {
                    "Diagnostics copied to clipboard.".to_owned()
                };
            }
        });
        ui.add_space(16.0);
    }

    /// Plain-text report copied by the "Copy diagnostics" button.
    fn diagnostics_report(&self, french: bool) -> String {
        let recent_errors = self
            .last_tick_errors
            .iter()
            .take(5)
            .map(|(session_id, error)| {
                if french {
                    format!("Session {} : {error}", session_id.get())
                } else {
                    format!("Session {}: {error}", session_id.get())
                }
            })
            .collect::<Vec<_>>()
            .join("\n");
        let active_session = self
            .controller
            .active_session()
            .map(|id| id.get().to_string())
            .unwrap_or_else(|| "none".to_owned());
        let config = self
            .config_path
            .as_deref()
            .map(|path| path.display().to_string());
        let staged = self
            .staged_update_path
            .as_deref()
            .map(|path| path.display().to_string());
        let version = option_env!("CARGO_PKG_VERSION");
        if french {
            format!(
                "ArchiaEmu {}\nPlateforme : {} / {}\nÉléments de la bibliothèque : {}\nSessions ouvertes : {}\nSession active : {}\nErreurs d’exécution : {}\nConfiguration : {}\nÉtat des médias : {}\nÉtat des mises à jour : {}\nMise à jour préparée : {}\nDernier message : {}\nErreurs récentes :\n{}",
                version.unwrap_or("inconnue"),
                std::env::consts::OS,
                std::env::consts::ARCH,
                self.controller.library().len(),
                self.controller.session_summaries().len(),
                active_session,
                self.last_tick_errors.len(),
                config.unwrap_or_else(|| "indisponible".to_owned()),
                self.media_status,
                self.update_status,
                staged.unwrap_or_else(|| "aucune".to_owned()),
                self.message,
                recent_errors
            )
        } else {
            format!(
                "ArchiaEmu {}\nPlatform: {} / {}\nLibrary items: {}\nOpen sessions: {}\nActive session: {}\nExecution errors: {}\nConfiguration: {}\nMedia status: {}\nUpdate status: {}\nStaged update: {}\nLatest message: {}\nRecent errors:\n{}",
                version.unwrap_or("unknown"),
                std::env::consts::OS,
                std::env::consts::ARCH,
                self.controller.library().len(),
                self.controller.session_summaries().len(),
                active_session,
                self.last_tick_errors.len(),
                config.unwrap_or_else(|| "unavailable".to_owned()),
                self.media_status,
                self.update_status,
                staged.unwrap_or_else(|| "none".to_owned()),
                self.message,
                recent_errors
            )
        }
    }
}
